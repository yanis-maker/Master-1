# Utilisation du programme

- Pour pouvoir lancer le programme il faut avoir **python** et une connexion internet
- Tout ce que vous avez à faire c'est de lancer le programme et de vous laisser guider
- Lors du lancement il vous sera demandé de rentrer le premier terme, ensuite le deuxième terme et enfin le nom de la relation
- Ensuite, il vous faudra choisir le type d'inférence que vous voulez avoir. Pour cela Il vous suffit de rentrer **1** pour **oui** et **0** pour **non**
- Une fois cela fait, le programme se lance et il ne reste plus qu'à attendre. Généralment si vous choisissez toutes les inférences le programme ne devrait pas prendre plus de 10 minutes.